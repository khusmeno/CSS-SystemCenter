export function renderMPList(mpArray, onSelect) {
  const listSection = document.getElementById("mp-list");
  listSection.innerHTML = "<h2>Available Management Packs</h2>";

  const ul = document.createElement("ul");
  mpArray.forEach(mp => {
    const li = document.createElement("li");
    li.textContent = mp.name;
    li.onclick = () => onSelect(mp);
    ul.appendChild(li);
  });
  listSection.appendChild(ul);
}

export function renderMPDetails(mp) {
  const detailsContainer  = document.getElementById("mp-detail");
	detailsContainer.innerHTML = `
    <div style="padding: 20px; border: 1px solid #ddd; border-radius: 8px; background: #f9f9f9;">
      <h2 style="margin-top: 0; color: #333;">${mp.name}</h2>
      <p style="margin: 8px 0; font-size: 16px;">
        <strong>Version:</strong> ${mp.version}
      </p>
      <p style="margin: 8px 0; font-size: 16px;">
        ${mp.description}
      </p>
      <a href="${mp.url}" target="_blank" style="display: inline-block; margin-top: 12px; padding: 8px 16px; background-color: #007bff; color: #fff; text-decoration: none; border-radius: 4px;">
        View Raw XML
      </a>
    </div>
  `;
}
