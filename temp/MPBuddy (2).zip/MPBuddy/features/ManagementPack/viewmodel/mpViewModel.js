import { fetchMPXml } from "../model/mpModel.js";
import { renderMPList, renderMPDetails } from "../view/mpView.js";

const exampleMPs = [
  {
    name: "Windows Library",
    url: "https://raw.githubusercontent.com/khusmeno/CSS-SystemCenter/main/MPBuddy_Data/Microsoft.Windows.Library/7.5.8501.0/Microsoft.Windows.Library.xml"
  },
  {
    name: "System Library",
    url: "https://raw.githubusercontent.com/khusmeno/CSS-SystemCenter/main/MPBuddy_Data/System.Library/7.5.8501.0/System.Library.xml"
  }
];

function parseMPInfo(xmlDoc) {
  const manifest = xmlDoc.querySelector("Manifest");
  const identity = manifest?.querySelector("Identity");

  return {
    name: identity?.querySelector("ID")?.textContent || "Unknown",
    version: identity?.querySelector("Version")?.textContent || "N/A",
    description: manifest?.querySelector("Description")?.textContent || "No description"
  };
}

async function initialize() {
  const mpData = await Promise.all(
    exampleMPs.map(async mp => {
      const xml = await fetchMPXml(mp.url);
      const parsed = parseMPInfo(xml);
      return { ...parsed, url: mp.url };
    })
  );

  renderMPList(mpData, renderMPDetails);
}

initialize();
