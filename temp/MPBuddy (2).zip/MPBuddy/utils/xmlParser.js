// Utility placeholder for XML parsing if needed
export function getTextContent(xml, tag) {
  const el = xml.querySelector(tag);
  return el ? el.textContent : "";
}
